package com.camunda.dto;


import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"id",
"name",
"assignee",
"created",
"due",
"followUp",
"delegationState",
"description",
"executionId",
"owner",
"parentTaskId",
"priority",
"processDefinitionId",
"processInstanceId",
"taskDefinitionKey",
"caseExecutionId",
"caseInstanceId",
"caseDefinitionId",
"suspended",
"formKey",
"tenantId"
})
public class TaskDetails {

@JsonProperty("id")
private String id;
@JsonProperty("name")
private String name;
@JsonProperty("assignee")
private String assignee;
@JsonProperty("created")
private String created;
@JsonProperty("due")
private Object due;
@JsonProperty("followUp")
private Object followUp;
@JsonProperty("delegationState")
private Object delegationState;
@JsonProperty("description")
private Object description;
@JsonProperty("executionId")
private Object executionId;
@JsonProperty("owner")
private Object owner;
@JsonProperty("parentTaskId")
private Object parentTaskId;
@JsonProperty("priority")
private int priority;
@JsonProperty("processDefinitionId")
private Object processDefinitionId;
@JsonProperty("processInstanceId")
private Object processInstanceId;
@JsonProperty("taskDefinitionKey")
private String taskDefinitionKey;
@JsonProperty("caseExecutionId")
private String caseExecutionId;
@JsonProperty("caseInstanceId")
private String caseInstanceId;
@JsonProperty("caseDefinitionId")
private String caseDefinitionId;
@JsonProperty("suspended")
private boolean suspended;
@JsonProperty("formKey")
private String formKey;
@JsonProperty("tenantId")
private Object tenantId;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("id")
public String getId() {
return id;
}

@JsonProperty("id")
public void setId(String id) {
this.id = id;
}

@JsonProperty("name")
public String getName() {
return name;
}

@JsonProperty("name")
public void setName(String name) {
this.name = name;
}

@JsonProperty("assignee")
public String getAssignee() {
return assignee;
}

@JsonProperty("assignee")
public void setAssignee(String assignee) {
this.assignee = assignee;
}

@JsonProperty("created")
public String getCreated() {
return created;
}

@JsonProperty("created")
public void setCreated(String created) {
this.created = created;
}

@JsonProperty("due")
public Object getDue() {
return due;
}

@JsonProperty("due")
public void setDue(Object due) {
this.due = due;
}

@JsonProperty("followUp")
public Object getFollowUp() {
return followUp;
}

@JsonProperty("followUp")
public void setFollowUp(Object followUp) {
this.followUp = followUp;
}

@JsonProperty("delegationState")
public Object getDelegationState() {
return delegationState;
}

@JsonProperty("delegationState")
public void setDelegationState(Object delegationState) {
this.delegationState = delegationState;
}

@JsonProperty("description")
public Object getDescription() {
return description;
}

@JsonProperty("description")
public void setDescription(Object description) {
this.description = description;
}

@JsonProperty("executionId")
public Object getExecutionId() {
return executionId;
}

@JsonProperty("executionId")
public void setExecutionId(Object executionId) {
this.executionId = executionId;
}

@JsonProperty("owner")
public Object getOwner() {
return owner;
}

@JsonProperty("owner")
public void setOwner(Object owner) {
this.owner = owner;
}

@JsonProperty("parentTaskId")
public Object getParentTaskId() {
return parentTaskId;
}

@JsonProperty("parentTaskId")
public void setParentTaskId(Object parentTaskId) {
this.parentTaskId = parentTaskId;
}

@JsonProperty("priority")
public int getPriority() {
return priority;
}

@JsonProperty("priority")
public void setPriority(int priority) {
this.priority = priority;
}

@JsonProperty("processDefinitionId")
public Object getProcessDefinitionId() {
return processDefinitionId;
}

@JsonProperty("processDefinitionId")
public void setProcessDefinitionId(Object processDefinitionId) {
this.processDefinitionId = processDefinitionId;
}

@JsonProperty("processInstanceId")
public Object getProcessInstanceId() {
return processInstanceId;
}

@JsonProperty("processInstanceId")
public void setProcessInstanceId(Object processInstanceId) {
this.processInstanceId = processInstanceId;
}

@JsonProperty("taskDefinitionKey")
public String getTaskDefinitionKey() {
return taskDefinitionKey;
}

@JsonProperty("taskDefinitionKey")
public void setTaskDefinitionKey(String taskDefinitionKey) {
this.taskDefinitionKey = taskDefinitionKey;
}

@JsonProperty("caseExecutionId")
public String getCaseExecutionId() {
return caseExecutionId;
}

@JsonProperty("caseExecutionId")
public void setCaseExecutionId(String caseExecutionId) {
this.caseExecutionId = caseExecutionId;
}

@JsonProperty("caseInstanceId")
public String getCaseInstanceId() {
return caseInstanceId;
}

@JsonProperty("caseInstanceId")
public void setCaseInstanceId(String caseInstanceId) {
this.caseInstanceId = caseInstanceId;
}

@JsonProperty("caseDefinitionId")
public String getCaseDefinitionId() {
return caseDefinitionId;
}

@JsonProperty("caseDefinitionId")
public void setCaseDefinitionId(String caseDefinitionId) {
this.caseDefinitionId = caseDefinitionId;
}

@JsonProperty("suspended")
public boolean isSuspended() {
return suspended;
}

@JsonProperty("suspended")
public void setSuspended(boolean suspended) {
this.suspended = suspended;
}

@JsonProperty("formKey")
public String getFormKey() {
return formKey;
}

@JsonProperty("formKey")
public void setFormKey(String formKey) {
this.formKey = formKey;
}

@JsonProperty("tenantId")
public Object getTenantId() {
return tenantId;
}

@JsonProperty("tenantId")
public void setTenantId(Object tenantId) {
this.tenantId = tenantId;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

@Override
public String toString() {
return new ToStringBuilder(this).append("id", id).append("name", name).append("assignee", assignee).append("created", created).append("due", due).append("followUp", followUp).append("delegationState", delegationState).append("description", description).append("executionId", executionId).append("owner", owner).append("parentTaskId", parentTaskId).append("priority", priority).append("processDefinitionId", processDefinitionId).append("processInstanceId", processInstanceId).append("taskDefinitionKey", taskDefinitionKey).append("caseExecutionId", caseExecutionId).append("caseInstanceId", caseInstanceId).append("caseDefinitionId", caseDefinitionId).append("suspended", suspended).append("formKey", formKey).append("tenantId", tenantId).append("additionalProperties", additionalProperties).toString();
}



}
