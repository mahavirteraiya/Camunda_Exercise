package com.camunda.task;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;

import com.camunda.dto.TaskDetails;
@SpringBootApplication
public class CamundaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamundaApplication.class, args);
		
		RestTemplate restTemplate = new RestTemplate();
        TaskDetails[] taskDetail = restTemplate.getForObject("http://localhost:8080/engine-rest/task", TaskDetails[].class);
        
        System.out.println("Printing Task ID && Task Name");
        
        for (TaskDetails taskDetails : taskDetail) {
        	System.out.println( "ID : " + taskDetails.getId() +
        			            "," + 
        			            "Name : " + taskDetails.getName());
		}
        
        
	}
}
